<?php
    
/**
 * Dummy loader!
 */

            
// Copying dummy_events.xml
try {
    $source = Core_Model_Directory::getBasePathTo('/app/local/modules/TemplateCorporate/resources/dummy/app/sae/modules/Cms/data/dummy_events.xml');
    $destination = Core_Model_Directory::getBasePathTo('/app/sae/modules/Cms/data/dummy_events.xml');
    copy($source, $destination);
} catch (\Exception $e) {
    // Fails silently please!
}
            
// Copying dummy_events.xml
try {
    $source = Core_Model_Directory::getBasePathTo('/app/local/modules/TemplateCorporate/resources/dummy/app/sae/modules/Comment/data/dummy_events.xml');
    $destination = Core_Model_Directory::getBasePathTo('/app/sae/modules/Comment/data/dummy_events.xml');
    copy($source, $destination);
} catch (\Exception $e) {
    // Fails silently please!
}
            
// Copying dummy_events.xml
try {
    $source = Core_Model_Directory::getBasePathTo('/app/local/modules/TemplateCorporate/resources/dummy/app/sae/modules/Event/data/dummy_events.xml');
    $destination = Core_Model_Directory::getBasePathTo('/app/sae/modules/Event/data/dummy_events.xml');
    copy($source, $destination);
} catch (\Exception $e) {
    // Fails silently please!
}
            
// Copying dummy_events.xml
try {
    $source = Core_Model_Directory::getBasePathTo('/app/local/modules/TemplateCorporate/resources/dummy/app/sae/modules/Media/data/dummy_events.xml');
    $destination = Core_Model_Directory::getBasePathTo('/app/sae/modules/Media/data/dummy_events.xml');
    copy($source, $destination);
} catch (\Exception $e) {
    // Fails silently please!
}
            
// Copying dummy_events.xml
try {
    $source = Core_Model_Directory::getBasePathTo('/app/local/modules/TemplateCorporate/resources/dummy/app/sae/modules/Push/data/dummy_events.xml');
    $destination = Core_Model_Directory::getBasePathTo('/app/sae/modules/Push/data/dummy_events.xml');
    copy($source, $destination);
} catch (\Exception $e) {
    // Fails silently please!
}
            
// Copying dummy_events.xml
try {
    $source = Core_Model_Directory::getBasePathTo('/app/local/modules/TemplateCorporate/resources/dummy/app/sae/modules/Rss/data/dummy_events.xml');
    $destination = Core_Model_Directory::getBasePathTo('/app/sae/modules/Rss/data/dummy_events.xml');
    copy($source, $destination);
} catch (\Exception $e) {
    // Fails silently please!
}